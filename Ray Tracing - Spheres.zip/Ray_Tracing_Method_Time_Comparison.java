public class Ray_Tracing_Method_Time_Comparison{
  
  
  public static void main(String[] args){
    Spheres3 s = new Spheres3();
    s.main(args);
  }
}