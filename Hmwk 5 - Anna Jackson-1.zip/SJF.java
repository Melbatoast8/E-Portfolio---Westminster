/**
 * SJF Scheduling Algorithm
 */

import java.util.*;

public class SJF implements Algorithm
{
  private List<Task> queue;
  private Task currentTask;
  private ArrayList<Integer> response;
  private ArrayList<Integer> turnaround;
  
  public SJF(List<Task> queue) {
    this.queue = queue;
    response = new ArrayList<Integer>();
    turnaround = new ArrayList<Integer>();
  }
  
  /**
   * Invokes the scheduler
   */
  public void schedule(){
    System.out.println("SJF Scheduling \n");
    
    while (!queue.isEmpty()) {
      currentTask = pickNextTask();
      response.add(CPU.getTime());
      CPU.run(currentTask, currentTask.getBurst());
      
      // we can get the current CPU time
      turnaround.add(CPU.getTime());
    }
  }
  
  /**
   * Selects the next task using the appropriate scheduling algorithm
   */
  public Task pickNextTask(){
    int i = queue.size() - 1;
    Task t = null;
    int burst = 100000;
    for (; i >= 0; i--){
      if (queue.get(i).getBurst() <= burst){
        burst = queue.get(i).getBurst();
        t = queue.get(i);
      }
    }
    queue.remove(t);
    return t;
  }
  
  /**
   * Reports average wait time of all tasks
   */
  public double getAverageWaitTime(){
    return getAverageResponseTime();
  }
  
  /**
   * Reports average turnaround time of all tasks
   */
  public double getAverageTurnaroundTime() {
    int sum = 0;
    int count = 0;
    while (count < turnaround.size()){
      sum += turnaround.get(count);
      count++;
    }
    return (double)sum / (double) count;
  }
  
  /**
   * Reports average response time of all tasks
   */
  public double getAverageResponseTime() {
    int sum = 0;
    int count = 0;
    while (count < response.size()){
      sum += response.get(count);
      count++;
    }
    return (double)sum / (double) count;
  }
}
