/**
 * Anna Jackson
 * CMPT 351
 * Hmwk. 5
 * 
 * RR Scheduling Algorithm
 */

import java.util.*;

public class RR implements Algorithm
{
  private List<Task> queue;
  private Task currentTask;
  static final int timeQuantum = 10;
  private int response;
  private ArrayList<Integer> turnaround;
  private int wait;
  private int numTasks;
  private ArrayList<Integer> beginWait;
  
  public RR(List<Task> queue) {
    this.queue = queue;
    response = 0;
    turnaround = new ArrayList<Integer>();
    beginWait = new ArrayList<Integer>();
    wait = 0;
    numTasks = queue.size();
  }
  
  /**
   * Invokes the scheduler
   */
  public void schedule(){
    System.out.println("RR Scheduling \n");
    ArrayList<Task> equal;
    
    while (!queue.isEmpty()) {
      equal = pickNextTasks();
      currentTask = equal.get(0);
      int size = equal.size();
      if (size == 1){ // only one task has this priority
        response += CPU.getTime();
        wait += CPU.getTime();
        CPU.run(currentTask, currentTask.getBurst());
        turnaround.add(CPU.getTime());
      }
      else {
        beginWait.clear();
        do { // round-robin loop with time quantum of 10
          if (size > 0){
            beginWait.add(0, CPU.getTime());
            wait += CPU.getTime();
            response += CPU.getTime();
            size--;
          }
          wait += CPU.getTime() - beginWait.remove(0);
          currentTask = equal.get(0);
          if (currentTask.getBurst() - timeQuantum <= 0){ // if task will finish within time quantum
            CPU.run(currentTask, currentTask.getBurst());
            turnaround.add(CPU.getTime());
            equal.remove(currentTask);
          }
          else {
            CPU.run(currentTask, timeQuantum);
            beginWait.add(CPU.getTime());
            Task temp = equal.remove(0);
            equal.add(temp);
          }
          currentTask.setBurst(currentTask.getBurst() - timeQuantum);
        }
        while (!equal.isEmpty());
      }
    }
    
    // we can get the current CPU time
    CPU.getTime();
  }
  
  /**
   * Selects the next tasks using the appropriate scheduling algorithm
   * returns an ArrayList of tasks with equal priority
   */
  public ArrayList<Task> pickNextTasks(){
    List<Task> equal = new ArrayList<Task>();
    int i = queue.size() - 1;
    Task t = null;
    int priority = -1;
    for (; i >= 0; i--){
      if (queue.get(i).getPriority() > priority){
        equal.clear();
        priority = queue.get(i).getPriority();
        equal.add(queue.get(i));
      }
      else if (queue.get(i).getPriority() == priority)
        equal.add(queue.get(i));
    }
    for(i = queue.size() - 1; i >= 0; i--){
      t = queue.get(i);
      if (t.getPriority() == priority)
        queue.remove(t);
    }
    return (ArrayList<Task>)equal;
  }
  
  // overrides pickNextTask() in Algorithm class
  public Task pickNextTask(){
    return null;
  }
  
  /**
   * Reports average wait time of all tasks
   */
  public double getAverageWaitTime(){
    return (double)wait / (double)numTasks;
  }
  
  /**
   * Reports average turnaround time of all tasks
   */
  public double getAverageTurnaroundTime(){
    int sum = 0;
    int count = 0;
    while (count < turnaround.size()){
      sum += turnaround.get(count);
      count++;
    }
    return (double)sum / (double) count;
  }
  
  /**
   * Reports average response time of all tasks
   */
  public double getAverageResponseTime(){
    return (double)response / (double)numTasks;
  }
}
