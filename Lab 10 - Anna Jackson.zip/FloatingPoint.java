/* Anna Jackson
 * Crystal Olsen
 * Lab 10
 */

import java.util.Scanner;

public class FloatingPoint {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		String word;
		boolean isAcceptance = false;
		
		System.out.println("Please enter a floating point number: \n");
		word = in.nextLine();
		isAcceptance = findAcceptanceState(word);
		
		
		if ( isAcceptance )
			System.out.println("Floating point accepted!\n");
		else
			System.out.println("Floating point not accepted!\n");
		
		

	}
	
	public static boolean findAcceptanceState(String word){
		
		int[][] stateArray = initializeArray(7,5);
		char currentChar;
		int stateNum = 0;
		
		for (int i = 0; i < word.length(); i++){
			currentChar = word.charAt(i);
			
			switch (currentChar){
			
				case ' ': stateNum = stateArray[stateNum][0];
					break;
				case '+': 
				case '-': 
					stateNum = stateArray[stateNum][1];
					break;
				case '.': stateNum = stateArray[stateNum][3];
					break; 
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					stateNum = stateArray[stateNum][2];
					break;
				default: stateNum = stateArray[stateNum][4];
			}
			
		}
		
		if (( stateNum == 4 ) || ( stateNum == 5 )){
			return true;
		}
		else 
			return false;
		
	}
	
	public static int[][] initializeArray(int row, int column){
		
		int[][] stateArray = {
				{0, 1, 2, 6, 6},
				{6, 6, 2, 6, 6},
				{6, 6, 2, 3, 6},
				{6, 6, 4, 6, 6},
				{5, 6, 4, 6, 6},
				{5, 6, 6, 6, 6},
				{6, 6, 6, 6, 6}};
		
		return stateArray;
	}

}
