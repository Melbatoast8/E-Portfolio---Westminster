/* Anna Jackson
 * Lab 10
 */

import java.util.Scanner;

public class ExtraCredit {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		String word;
		boolean isAcceptance = false;
		
		System.out.println("Please enter a floating point number: \n");
		word = in.nextLine();
		isAcceptance = findAcceptanceState(word);
		
		
		if ( isAcceptance )
			System.out.println("Floating point accepted!\n");
		else
			System.out.println("Floating point not accepted!\n");
		
		

	}
	
	public static boolean findAcceptanceState(String word){
		
		int[][] stateArray = initializeArray(9,6);
		char currentChar;
		int stateNum = 0;
		
		for (int i = 0; i < word.length(); i++){
			currentChar = word.charAt(i);
			
			switch (currentChar){
			
				case ' ': stateNum = stateArray[stateNum][0];
					break;
				case '+': 
				case '-': 
					stateNum = stateArray[stateNum][1];
					break;
				case '.': stateNum = stateArray[stateNum][3];
					break; 
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					stateNum = stateArray[stateNum][2];
					break;
				case 'E':
				case 'e':
					stateNum = stateArray[stateNum][4];
					break;
				default: stateNum = stateArray[stateNum][5];
			}
			
		}
		
		if (( stateNum == 2 ) || ( stateNum == 5 ) || ( stateNum == 6 )){
			return true;
		}
		else 
			return false;
		
	}
	
	public static int[][] initializeArray(int row, int column){
		
		int[][] stateArray = {
				{0, 1, 1, 7, 8, 8},
				{8, 8, 1, 2, 8, 8},
				{6, 8, 2, 8, 3, 8},
				{8, 4, 5, 8, 8, 8},
				{8, 8, 5, 8, 8, 8},
				{6, 8, 5, 8, 8, 8},
				{6, 8, 8, 8, 8, 8},
				{8, 8, 2, 8, 8, 8},
				{8, 8, 8, 8, 8, 8}};
		
		return stateArray;
	}

}