import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Spheres2 {
  
  public List_Of_Spheres list = new List_Of_Spheres();
  private static float[] color = new float[3];
  
  public Hit_Sphere hitSphere(Vec3 v, Sphere sphere, Vec3 origin){
    Vec3 center = sphere.center.subtract(origin);
    double angle = Math.abs((double)(v.getAngle(center)));
    if (angle < (Math.PI/2)){
      //if (v.dot_product(center) > 0) {
        double a = center.getLength()*Math.abs(Math.sin(angle));
        if (a <= sphere.radius)
          return new Hit_Sphere(a,sphere,v,origin);
    //  }
    }
    return null;
  }
  
  public Hit_Sphere hitSphere(Vec3 v, Vec3 origin, int start_index){ // start_index needed?- usually 0
    int numOfSpheres = list.length;
    float min_length = Float.MAX_VALUE;
    Hit_Sphere hit;
    Hit_Sphere closest_hit = null;
    for (; start_index < numOfSpheres; start_index++){
      hit = hitSphere(v, list.get(start_index), origin);
      if (hit != null){
        if (hit.proximity < min_length){
          min_length = hit.proximity;
          closest_hit = hit;
        }
      }
    }
    return closest_hit;
  }
  
  public Vec3 color_at_end_of_ray(Vec3 v, Vec3 origin){
    Hit_Sphere hit = hitSphere(v, origin, 0);
    if (hit != null){
      hit.hit_point = hit.hit_point();
      if (hit.sphere.reflective){
        Vec3 n = v.surface_normal(hit.hit_point, hit.sphere.center, hit.sphere.radius);
        Vec3 d = v.unit_vector();
        Vec3 reflect = d.subtract(n.multiply(d.dot_product(n)*2));
//        Vec3 reflect = v.subtract(n.multiply(v.dot_product(n)*2));
        return this.color_at_end_of_ray(reflect, hit.hit_point); // add depth
      }
      if (hitSphere(new Vec3(0,1,0), hit.hit_point, 0) != null) // shadow
        return new Vec3(0,0,0);
      else if (hit.sphere.light)
        return new Vec3(1,1,1);
      else {
        float color[] = new float[3];
//        for (int k = 0; k<3; k++)
//          color[k] = raw_color[k]*(Math.max((float)0.0, v.surface_normal_r1(v.hit_point((float)radius[2], list.get(sphere_index).center, rad), list.get(sphere_index)).getY()));
        color[0] = hit.sphere.color.getX()*(Math.max((float)0.0, v.surface_normal(hit.hit_point, hit.sphere.center, hit.sphere.radius).getY()));
        color[1] = hit.sphere.color.getY()*(Math.max((float)0.0, v.surface_normal(hit.hit_point, hit.sphere.center, hit.sphere.radius).getY()));
        color[2] = hit.sphere.color.getZ()*(Math.max((float)0.0, v.surface_normal(hit.hit_point, hit.sphere.center, hit.sphere.radius).getY()));
//        Vec3 test = v.surface_normal(hit.hit_point,hit.sphere.center, hit.sphere.radius);
//        System.out.println(test.getX() + " " + test.getY() + " " + test.getZ() + " ");
        return new Vec3(color[0], color[1], color[2]);
      }
    }
    else {
      
      float y = (float)0.2*(1-v.getY());
      return new Vec3(0,y, (float)(25/255));
      
      
      
//      Vec3 vec = Vec3.surface_normal(hit.hit_point(), hit.sphere.center, hit.sphere.radius);
//      float nx = vec.getX();
//      float ny = vec.getY();
//      float nz = vec.getZ();
//      return new Vec3((nx+1)/2, (ny+1)/2, (nz+1)/2);
    }
  }
  
  public static void main(String[] args){
    Spheres2 sph = new Spheres2();
    float height =256;
    float width = 256;
    
    sph.list.add(0,0,-3,1);
    sph.list.get(0).color = new Vec3(1, (float)0.5, (float)0.5);
    sph.list.add(2,0,-4,1);
    sph.list.get(1).color = new Vec3((float)0.5, 1, (float)0.5);
    sph.list.add(-2,0,-3,1);
    sph.list.get(2).color = new Vec3((float)0.5, (float)0.5, 1);
    sph.list.add(0,-100,0,(float)98.5);
    sph.list.get(3).light = true;
    sph.list.add(0,10,0,1);
    sph.list.get(4).light = true;
    
    try {
      PrintStream out = new PrintStream(new FileOutputStream("C:\\Users\\Anna's\\Downloads\\CMPT 360\\image.ppm"));
      System.setOut(out);
      
      System.out.println("P3");
      System.out.println(("256 256"));
      System.out.println("255");
      
      for (float i = 0; i < height; i++){
        
        for (float j = 0; j < width; j++){ 
          
          Vec3 direction = new Vec3(-1+2*(j/(width-1)),1-2*(i/(height-1)),-1);
          //         System.out.print(direction.getX() + " " + direction.getY() + " " + direction.getZ() + " ");
          
          Vec3 color = sph.color_at_end_of_ray(direction, new Vec3((float)0,(float)0,(float)0));
          System.out.print((int)(255*color.getX()) + " " + (int)(255*color.getY()) + " " + (int)(255*color.getZ()) + " ");
//          else{
//            Vec3 vec = Vec3.surface_normal(direction);
//            float nx = vec.getX();
//            float ny = vec.getY();
//            float nz = vec.getZ();
//            System.out.print((int)(255*((nx + 1)/2)) + " " + (int)(255*((ny + 1)/2)) + " " + (int)(255*((nz + 1)/2)) + " ");
//          }
        }
        System.out.println();
      }
    }
    catch(IOException e){
      System.out.println("IOE");
    }
  }
  
}