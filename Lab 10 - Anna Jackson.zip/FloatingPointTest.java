/* Anna Jackson
 * Crystal Olsen
 * 
 * Lab 10
 */

import junit.framework.TestCase;


public class FloatingPointTest extends TestCase{

	public void test1() {
		assertFalse(FloatingPoint.findAcceptanceState(".876"));
		assertFalse(FloatingPoint.findAcceptanceState("897 987.876"));
		assertFalse(FloatingPoint.findAcceptanceState(".87math6"));
		assertTrue(FloatingPoint.findAcceptanceState("+6.876"));
		assertTrue(FloatingPoint.findAcceptanceState("-89.876"));
		assertTrue(FloatingPoint.findAcceptanceState("  7879.876"));
		assertTrue(FloatingPoint.findAcceptanceState("7.876 "));
		assertFalse(FloatingPoint.findAcceptanceState("0.8+76"));
		assertTrue(FloatingPoint.findAcceptanceState("0000.876"));
		assertFalse(FloatingPoint.findAcceptanceState(""));
	}

}
