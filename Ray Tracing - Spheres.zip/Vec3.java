public class Vec3 {
  
  public float x;
  public float y;
  public float z;
  private float length;
  //private float var = 0;
  
  public Vec3(float x_value, float y_value, float z_value){
    x = x_value;
    y = y_value;
    z = z_value;
    length = this.getLength();
  }
  
//  public void setVar(float v){
//    var = v;
//  }
  
  public float getX(){
    return x;
  }
  
  public float getY(){
    return y;
  }
  
  public float getZ(){
    return z;
  }
  
  public float getLength(){
    float a = x*x + y*y + z*z;
    return (float)Math.sqrt(a);
  }
  
  public float getLength(Vec3 origin){
    float a = (x-origin.getX())*(x-origin.getX()) + (y-origin.getY())*(y-origin.getY()) + (z-origin.getZ())*(z-origin.getZ());
    return (float)Math.sqrt(a);
  }
  
  public float normal(float a){
    return a/length;
  }
  
  public Vec3 unit_vector(){
    return new Vec3(x/length, y/length, z/length);
  }
  
//  public Vec3 hit_point(float rad, Vec3 vec, float var){
//    float div = Math.abs(this.length / (((1/(float)Math.tan((double)this.getAngle(vec)))*var) - rad)); 
////    if (div < 0.01)
////      return null;
//    return new Vec3((this.x)/div, (this.y)/div, (this.z)/div);
//  }
  
  public Vec3 surface_normal_r1(Vec3 p, Vec3 c){
    return new Vec3(p.getX()-c.getX(), p.getY()-c.getY(), p.getZ()-c.getZ());
  }
  
  public static Vec3 surface_normal(Vec3 p, Vec3 c, float r){
//    System.out.println(p.getX() + " " + p.getY() + " " + p.getZ() + " ");
//    
//    System.out.println(c.getX() + " " + c.getY() + " " + c.getZ() + " ");
    return new Vec3((p.getX()-c.getX())/r, (p.getY()-c.getY())/r, (p.getZ()-c.getZ())/r);
  }
  
  public Vec3 add(Vec3 v){
    return new Vec3(this.x+v.getX(), this.y+v.getY(), this.z+v.getZ());
  }
  
  public Vec3 subtract(Vec3 v){
    return new Vec3(this.x-v.getX(), this.y-v.getY(), this.z-v.getZ());
  }
  
  public Vec3 multiply(float num){
    Vec3 product = new Vec3(this.x*num, this.y*num, this.z*num);
    return product;
  }
  
  public float dot_product(Vec3 second){
    float x_sum = this.getX() * second.getX();
    float y_sum = this.getY() * second.getY();
    float z_sum = this.getZ() * second.getZ();
    return x_sum + y_sum + z_sum;
  }
  
  public float getAngle(Vec3 second){
    float a = dot_product(second) / this.getLength() / second.getLength();
    return (float)(Math.acos((double)a));
  }
  
  
  
}