/* Anna Jackson
 * Lab 10
 */

import junit.framework.TestCase;


public class ExtraCreditTest extends TestCase{

	public void test1() {
		assertTrue(ExtraCredit.findAcceptanceState(".876e9"));
		assertTrue(ExtraCredit.findAcceptanceState(".876E8"));
		assertTrue(ExtraCredit.findAcceptanceState(".876e+11"));
		assertTrue(ExtraCredit.findAcceptanceState(".876E-4"));
		assertFalse(ExtraCredit.findAcceptanceState(".e2"));
		assertFalse(ExtraCredit.findAcceptanceState("."));
		assertTrue(ExtraCredit.findAcceptanceState(".876"));
		assertFalse(ExtraCredit.findAcceptanceState("897 987.876"));
		assertFalse(ExtraCredit.findAcceptanceState(".87math6"));
		assertTrue(ExtraCredit.findAcceptanceState("+6.876"));
		assertTrue(ExtraCredit.findAcceptanceState("-89.876"));
		assertTrue(ExtraCredit.findAcceptanceState("  7879.876"));
		assertTrue(ExtraCredit.findAcceptanceState("7.876 "));
		assertFalse(ExtraCredit.findAcceptanceState("0.8+76"));
		assertTrue(ExtraCredit.findAcceptanceState("0000.876"));
		assertFalse(ExtraCredit.findAcceptanceState(""));
	}

}
