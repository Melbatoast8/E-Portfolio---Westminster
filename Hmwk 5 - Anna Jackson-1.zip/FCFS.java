/**
 * Anna Jackson
 * CMPT 351
 * Hmwk. 5
 * 
 * FCFS scheduling algorithm.
 */

import java.util.*;

public class FCFS implements Algorithm
{
  private List<Task> queue;
  private Task currentTask;
  private ArrayList<Integer> response;
  private ArrayList<Integer> turnaround;
  
  public FCFS(List<Task> queue) {
    this.queue = queue;
    response = new ArrayList<Integer>();
    turnaround = new ArrayList<Integer>();
  }
  
  public void schedule() {
    System.out.println("FCFS Scheduling \n");
    
    while (!queue.isEmpty()) {
      currentTask = pickNextTask();
      response.add(CPU.getTime());
      CPU.run(currentTask, currentTask.getBurst());
      
      // we can get the current CPU time
      turnaround.add(CPU.getTime());
    }
  }
  
  public Task pickNextTask() {
    return queue.remove(0);
  }
  
  public double getAverageWaitTime() {
    return getAverageResponseTime();
  }
  
  public double getAverageResponseTime() {
    int sum = 0;
    int count = 0;
    while (count < turnaround.size()){
      sum += response.get(count);
      count++;
    }
    return (double)sum / (double) count;
  }
  
  public double getAverageTurnaroundTime() {
    int sum = 0;
    int count = 0;
    while (count < response.size()){
      sum += turnaround.get(count);
      count++;
    }
    return (double)sum / (double) count;
  }
}
